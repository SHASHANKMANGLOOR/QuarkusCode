Quarkus guide: https://quarkus.io/guides/rest-client-reactive
