package org.acme.rest.client;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class ExtensionsResourceIT extends JokesResourceTest {

    // Execute the same tests but in native mode.
}
